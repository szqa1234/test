function login() {
	window.location.href = "http://127.0.0.1:5000/api.html";
}